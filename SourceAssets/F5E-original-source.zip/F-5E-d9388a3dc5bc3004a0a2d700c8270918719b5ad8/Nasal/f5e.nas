# Northrop F-5E NASAL Settings
# Isaias V. Prestes - PRESTES Hangar - 2009

#setprop("/canopy/position-norm", 1);

 #setprop("/controls/lighting/landing-lights", "false");
 #setprop("/controls/lighting/beacon", "false");
# setprop("/controls/lighting/strobe", "false");
 #setprop("/controls/lighting/nav-lights", "false");
 #setprop("/controls/lighting/cabin-lights", "false");
 #setprop("/controls/lighting/wing-lights", "false");
 #setprop("/controls/lighting/taxi-light", "false");
 #setprop("/controls/switches/landing-light", "false");
 #setprop("/controls/switches/beacon", "false");
 #setprop("/controls/switches/strobe", "false");
 #setprop("/controls/switches/nav-lights", "false");
 #setprop("/controls/switches/taxi-lights", "false");

setlistener("/sim/current-view/view-number", func(n) setprop("/sim/hud/visibility[1]", !n.getValue()), 1);



## Smoke ##

SmokeToggle = func
{
  var smoke=props.globals.getNode("/smoke");
  smoke.getChild("active").setValue(!smoke.getChild("active").getValue());
}

SmokeColor = func
{
  var smoke=props.globals.getNode("/smoke");
  #form white to red
  if(smoke.getChild("color").getValue()=="white") {
    smoke.getChild("color").setValue("red");
    smoke.getChild("red").setValue(0.867);
    smoke.getChild("green").setValue(0.133);
    smoke.getChild("blue").setValue(0.133);
  }
  #from red to green
  else if(smoke.getChild("color").getValue()=="red") {
    smoke.getChild("color").setValue("green");
    smoke.getChild("red").setValue(0.0);
    smoke.getChild("green").setValue(0.533);
    smoke.getChild("blue").setValue(0.267);
  }
  #from green to white
  else if(smoke.getChild("color").getValue()=="green") {
    smoke.getChild("color").setValue("blue");
    smoke.getChild("red").setValue(0.0);
    smoke.getChild("green").setValue(0.0);
    smoke.getChild("blue").setValue(1.0);
  }
  #from blue to white
  else if(smoke.getChild("color").getValue()=="blue") {
    smoke.getChild("color").setValue("white");
    smoke.getChild("red").setValue(1.0);
    smoke.getChild("green").setValue(1.0);
    smoke.getChild("blue").setValue(1.0);
  }
  #from otherwise to white
  else {
    smoke.getChild("color").setValue("white");
    smoke.getChild("red").setValue(1.0);
    smoke.getChild("green").setValue(1.0);
    smoke.getChild("blue").setValue(1.0);
  }
}

SmokeCounter = func(step)
{
  var smoke=props.globals.getNode("/smoke");
  smoke.getChild("particlepersec").setValue(smoke.getChild("particlepersec").getValue()+step);
  if(smoke.getChild("particlepersec").getValue()<0) {
    smoke.getChild("particlepersec").setValue(0);
  }
  i=0;
  var smokeai=props.globals.getNode("/ai/models/multiplayer[0]");
  while(smokeai!=nil) {
    if(smokeai.getNode("sim/model/path").getValue()=="Aircraft/F-5E/Models/F-5Emin.xml") {
      smokeai.getNode("smoke/particlepersec").setValue(smoke.getChild("particlepersec").getValue());
    }
    i=i+1;
    smokeai=props.globals.getNode("/ai/models/multiplayer["~i~"]");
  }
  print("Smoke particle per second: ",smoke.getChild("particlepersec").getValue());
}

# Autorstart/Autoshutdown provedure

var batstart= func {
	setprop("controls/electric/battery-switch",1);
	gui.popupTip("System on battery, starting APU!");
}

var apustart= func {
	setprop("controls/APU/off-start-run", 1);
	setprop("controls/electric/APU-generator", 1);
	gui.popupTip("APU starting!");
}

var pump0start= func {
	setprop("controls/fuel/tank[0]/boost-pump[0]", 1);
	setprop("controls/fuel/tank[0]/boost-pump[1]", 1);
	gui.popupTip("Fuel pumps wing tank left starting!");
}

var pump2start= func {
	setprop("controls/fuel/tank[2]/boost-pump[0]", 1);
	setprop("controls/fuel/tank[2]/boost-pump[1]", 1);
	gui.popupTip("Fuel pumps wing tank right starting!");
}

var pump1start= func {
	setprop("controls/fuel/tank[1]/boost-pump[0]", 1);
	setprop("controls/fuel/tank[1]/boost-pump[1]", 1);
	gui.popupTip("Fuel pumps center tank starting!");
}

var eng1start= func {
	setprop("controls/electric/engine[0]/bus-tie",1);
	setprop("controls/electric/engine[0]/generator",1);
	setprop("controls/engines/engine[0]/cutoff", 1);	# needs to be true for JSB to spin up with starter
	setprop("controls/engines/engine[0]/fuel-pump", 1);
	setprop("controls/engines/engine[0]/ignition", 1);
	setprop("controls/engines/engine[0]/starter", 1);
	gui.popupTip("Engine 1 starting!");
}

var eng2start= func {
	setprop("controls/electric/engine[1]/bus-tie",1);
	setprop("controls/electric/engine[1]/generator",1);
	setprop("controls/engines/engine[1]/cutoff", 1);	# needs to be true for JSB to spin up with starter
	setprop("controls/engines/engine[1]/fuel-pump", 1);
	setprop("controls/engines/engine[1]/ignition", 1);
	setprop("controls/engines/engine[1]/starter", 1);
	gui.popupTip("Engine 2 starting!");
}

var eng1norm= func {
	setprop("controls/engines/engine[0]/cutoff", 0);	# now cutoff to false to make her run on her own
	gui.popupTip("Engine 1 spinning up!");
}

var eng2norm= func {
	setprop("controls/engines/engine[1]/cutoff", 0);	# now cutoff to false to make her run on her own
	gui.popupTip("Engine 2 spinning up!");
}

var eng1watch= func {
	var n2=getprop("fdm/jsbsim/propulsion/engine[0]/n2");
	if (n2<59) {
		settimer(eng1watch, 5);
		if (n2<1) {
			# re-trigger jsbsim to spin this engine up
			setprop("controls/engines/engine[0]/cutoff", 1);
			setprop("controls/engines/engine[0]/cutoff", 2);
		}
	} else {
		gui.popupTip("Engine 1 running!");
	}
}

var eng2watch= func {
	var n2=getprop("fdm/jsbsim/propulsion/engine[1]/n2");
	if (n2<59) {
		settimer(eng2watch, 5);
		if (n2<1) {
			# re-trigger jsbsim to spin this engine up
			setprop("controls/engines/engine[1]/cutoff", 1);
			setprop("controls/engines/engine[1]/cutoff", 2);
		}
	} else {
		gui.popupTip("Engine 2 running!");
	}
}

var Startup = func {
	settimer(batstart, 1);
	settimer(apustart, 6);
	settimer(pump0start, 8);
	settimer(pump2start, 10);
	settimer(pump1start, 12);
	settimer(eng1start, 12);
	settimer(eng2start, 18);
	settimer(eng1norm, 22);
	settimer(eng2norm, 28);
	settimer(eng1watch, 27);
	settimer(eng2watch, 32);

	# connect avionics, lights, etc
#	setprop("controls/electric/avionics-switch",1);
#	setprop("controls/electric/inverter-switch",1);
#	setprop("controls/lighting/instrument-norm",0.8);
#	setprop("controls/lighting/nav-lights",1);
#	setprop("controls/lighting/beacon",1);
#	setprop("controls/lighting/strobe",1);
#	setprop("controls/lighting/wing-lights",1);
#	setprop("controls/lighting/taxi-lights",1);
#	setprop("controls/lighting/logo-lights",1);
#	setprop("controls/lighting/cabin-lights",1);
#	setprop("controls/lighting/landing-light[0]",1);
#	setprop("controls/lighting/landing-light[1]",1);
#	setprop("controls/lighting/landing-light[2]",1);
#	setprop("controls/engines/engine[1]/cutoff",0);

#	setprop("controls/lighting/instruments-norm",0.8);
#	setprop("controls/lighting/instrument-lights-norm",0.8);
#	setprop("controls/lighting/efis-norm",0.8);
#	setprop("controls/lighting/panel-norm",0.8);
#	setprop("systems/electrical/volts",28);
}

var Shutdown = func{
setprop("controls/electric/engine[0]/generator",0);
setprop("controls/electric/engine[1]/generator",0);
setprop("controls/electric/engine[0]/bus-tie",0);
setprop("controls/electric/engine[1]/bus-tie",0);
setprop("controls/electric/APU-generator",0);
setprop("controls/electric/avionics-switch",0);
setprop("controls/electric/battery-switch",0);
setprop("controls/electric/inverter-switch",0);
setprop("controls/lighting/instruments-norm",0);
setprop("controls/lighting/instrument-norm",0.0);
setprop("controls/lighting/nav-lights",0);
setprop("controls/lighting/beacon",0);
setprop("controls/lighting/strobe",0);
setprop("controls/lighting/wing-lights",0);
setprop("controls/lighting/taxi-lights",0);
setprop("controls/lighting/logo-lights",0);
setprop("controls/lighting/cabin-lights",0);
setprop("controls/lighting/landing-light[0]",0);
setprop("controls/lighting/landing-light[1]",0);
setprop("controls/lighting/landing-light[2]",0);
setprop("controls/engines/engine[0]/cutoff",1);
setprop("controls/engines/engine[1]/cutoff",1);
setprop("controls/fuel/tank/boost-pump",0);
setprop("controls/fuel/tank/boost-pump[1]",0);
setprop("controls/fuel/tank[1]/boost-pump",0);
setprop("controls/fuel/tank[1]/boost-pump[1]",0);
setprop("controls/fuel/tank[2]/boost-pump",0);
setprop("controls/fuel/tank[2]/boost-pump[1]",0);
setprop("controls/lighting/instrument-lights-norm",0.0);
setprop("controls/lighting/efis-norm",0.0);
setprop("controls/lighting/panel-norm",0.0);
setprop("systems/electrical/volts",0.0);

}


setlistener("/sim/model/start-idling", func(idle) {
	var run= idle.getBoolValue();
	if (run) {
		Startup();
	} else {
		Shutdown();
	}
},0,0);

