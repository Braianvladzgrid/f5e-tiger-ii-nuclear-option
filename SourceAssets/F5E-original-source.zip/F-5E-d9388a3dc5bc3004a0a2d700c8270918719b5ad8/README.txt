FGUK's Northrop F-5E
--------------------

http://fguk.eu/index.php/hangar/viewdownload/8-military-jets/119-northrop-f-5e


![FGUK IMAGE](http://www.fguk.eu/images/jdownloads/screenshots/fgfs-screen-0080.png)

This aircraft requires the DAVE PACK available <a href="http://fguk.eu/Lee%20Elliott,%20Josh%20Babcock">HERE</a>

V0.4

* Advanced lighting kit on all versions.
* Updated sound pack.
* New Pilot
* Additional views.
* Cannons limited to 280 rounds each and can only be reloaded on the ground from the F5 menu.
* Added YASIM version using  YASIM CURRENT VERSION.
* Yasim version has  selectable weapons options available. Some pre defined loadouts are available from the F5 menu


****

<pre>
				 |                                             
                                 |                                             
                                 |                                             
                                _|_                                            
                               /___\                                           
                              /_____\                                          
                             /oo   oo\                                         
 \___________________________\       /___________________________/             
  `-----------|------|--------\_____/--------|------|-----------'              
             ( )    ( )     O|OOo|oOO|O     ( )    ( )                         
                                                                               
 P R E S T E S  H A N G A R  -- http://presteshangar.blogspot.com  --  2009-2010
--------------------------------------------------------------------------------

</pre>

LICENSE
---------

1. The PRESTES Hangar -  Valente Division -  work.

This work is under Creative Commons Attribution- Noncommercial- Share Alike 3.0 Unported license. Check LICENSE.txt file, or http://presteshangar.blogspot.com, or http://presteshangar.wikidot.com/start, for more information about license. 

(CC) 2010 Isaias V. Prestes (PRESTES Hangar)



1.2 Zexe Contribution December 7th, 2010.

December 14th, 2010:
- With the help of Buckaroo, the f5e.ac is now loadable in Blender.
- Fixed nozzle and nozzleneck texture.
- Animated wheels.
- Fixed here and there polygons.
- Added a new model called BlackChrome, loosely based on the Top Gun Mig 28.

December 7th, 2010:

- Scaled lights down.
- Added Dave's Altimeter.
- Changed canopy key binding to 'c' and fixed syntax.  In the previous version, the canopy could not change direction mid- way through, now the canopy can open and close whenever.
- Added turbine texture.
- Added new animated afterburner plumes.
- Added reheat, turbine when afterburners are on.
- Modified wing area and wing span so that the F5E Tiger II is controllable for stable landings.
- Added chute.  'd' deploys, 'j' jettison.  Chutes are carried over the MP network.  Chutes can only be deployed once.
- Removed old radar and added a non- functioning model radar.  Something weird happens with FG 2.0 Model View and Radar when radar is functioning.  Therefore radar has been disabled.
- Added new sounds: borrowed from the Eurofighter (gear up, gear down, gear not down, fuel low).  
- Added new sounds: Exceeding 7Gs will initiate a mimick of the Hick maneuver, and coming down below 5Gs will initiate heavy breathing.
- Added customized HUD for F5E Tiger II.  'shift + i' will bring it about.  Target markers are enabled.  Note: The modified HUD is made with the New HUD configuration. Also Gs and AoA are in the HUD, please don't get them confused.
- Sonic boom:  Shock wave added.  For best effect, watch in Fly- by View.
- Shortened the length of the condensation trail on the wing tip.
- New Splash screen, thanks to Michat.

To-  Do:

- Animate the wheels spinning.
- Get a functioning radar.
- Texture the inside of the cockpit.
- Create a F5E Tiger II model without the FuelTank load.


1.1 PRESTES Hangar -  Valente Division -  work

-  FDM ( F- 5E.xml )
-  F- 5E- set.xml
-  splash.png
-  J85- GE- 21B.xml
-  Fuselage textures (livery system)
-  Instruments (from others GPLed FG models)
-  f5e.ac panel parts and other addictions.

2. The Dave�s Culp Northrop F- 5E Tiger II version 0.1

    * Northrop F- 5E Tiger II
    * Source: Converted from a freeware Alpha Simulations model.
    * License: "CC- BY- NC- SA"
    * Compatibility: FlightGear 1.9.x
    * Coming soon.
    * Download preview (very alpha) version: F- 5E.tar.gz

3. Original Splash image

Splash screen imagem (C) J. A. Moraes.


The Northrop F- 5E Tiger II
---------------------------

The Northrop F- 5A/B Freedom Fighter and F- 5E/F Tiger II are part of a family of widely used light supersonic fighter aircraft, designed and built by Northrop in the United States, beginning in 1960s. Hundreds remain in service in air forces around the world in the early 21st Century, and the type has also been the basis for a number of other aircraft.
The F- 5 started life as a privately- funded light fighter program by Northrop in the 1950s. The first generation F- 5A Freedom Fighter entered service in the 1960s. Over 800 were produced through 1972 for U.S. allies during the Cold War. The USAF had no need for a light fighter, but it did specify a requirement for a supersonic trainer and procured about 1,200 of a derivative airframe for this purpose, the T- 38 Talon.
The improved second- generation F- 5E Tiger II was also primarily used by American Cold War allies and, in limited quantities, served in US military aviation as a training and aggressor aircraft; Tiger II production amounted to 1,400 of all versions, with production ending in 1987. Many F- 5s continuing in service into the 1990s and 2000s have undergone a wide variety of upgrade programs to keep pace with the changing combat environment. The F- 5 was also developed into a dedicated reconnaissance version, the RF- 5 Tigereye.
The F- 5 serves as a starting point for a series of design studies which resulted in the twin- tailed Northrop YF- 17 and the F/A- 18 series of carrier- based fighters. The F- 20 Tigershark was an advanced version of the F- 5E that did not find a market. The F- 5N/F variants remain in service with the United States Navy as an adversary trainer.[4]

SOURCE : http://en.wikipedia.org/wiki/Northrop_F- 5

CHANGELOG
----------

Varsion alpha -  0.0.4 04/07/2010
		-  New views, lights set, no limits version.
Version alpha -  0.0.3 04/03/2010
		-  FDM improvements, nose gear animation for strut extension, revised nose gear, revised nose_lift.xml system file and livery over MP fixed.
Version alpha -  0.0.2 20/12/2009
		-  FDM improvements, instrument texture and minor 3d model fixes.
Version alpha -  0.0.1 16/12/2009
		-  First presentation. Added panel, refueling, livery support, FDM improvements, - set.xml addictions and a realistic 3d panel.



Developed by Prestes Hangar, Valente division. Avaliable at http://presteshangar.blogspot.com or http://presteshangar.wikidot.com/start


INSTALATION
------------

Unpack this .zip file using TUGZip in FLIGHTGEAR_BASE_DIRECTORY\Data\Aircraft


Best regards,

Prestes Hangar

-----------------------------------

PORTUGU�S -  BRASIL

------------------------------------


LICEN�A
=======

1. O trabalho do PRESTES Hangar -  Divis�o Valente.

Este trabalho est�Esob a licen�a Creative Commons Attribution- Noncommercial- Share Alike 3.0 Unported. Veja o arquivo LICENSE.txt, ou http://presteshangar.blogspot.com, or http://presteshangar.wikidot.com/start, para mais informa��o sobre a licen�a. 

(CC) 2009 Isaias V. Prestes (PRESTES Hangar)



1.1 O trabalho do PRESTES Hangar -  Valente Division

-  FDM ( F- 5E.xml )
-  F- 5E- set.xml
-  splash.png
-  J85- GE- 21B.xml
-  Fuselage textures (livery system)
-  Instruments (de outros modelo GPLed do FG)
-  f5e.ac partes do painel

2. O Northrop F- 5E Tiger II de Dave Culp vers�o 0.1

    * Northrop F- 5E Tiger II
    * Origem: Convertido de um modelo Alpha Simulations freeware.
    * Licen�a: "CC- BY- NC- SA"
    * Compatibilidade: FlightGear 1.9.x


3. Splash image

Imagem de apresenta��o de Sotomayor, sob a licen�a Creative Commons, original em "Treino da For�a A�rea Brasileira" http://www.flickr.com/photos/59098052@N00/3831383541

    
O Northrop F- 5E Tiger II
========================

O Northrop F- 5E Tiger II �Eum ca�a t�tico de defesa a�rea e ataque ao solo. O F- 5E (vers�o mais potente do F- 5A Freedom Fighter) tornou- se um dos avi�es mais operados no mundo. A variante original F- 5A foi testada em combate no Vietn�E no Programa Skoshi Tiger. O F- 5E �Eextremamente manobr�vel e r�pido, constituindo- se um excelente avi�o para combates a�reos.

Recentemente, a FAB (For�a A�rea Brasileira) deu in��io a um programa de aquisi��o e moderniza��o de seus F- 5E que passar�o para o padr�o F- 5EM. A revitaliza��o dos 47 ca�as, dever�Ecustar em torno de US$ 285 milh�es. O motor e c�lula dos avi�es permanecer�o os mesmos, mas a sua eletr�nica (HUD, radar e painel de controle) ser�o extremamente modificados.

Atualmente, foram comemorados os 30 anos de servi�o da aeronave na For�a A�rea Brasileira, sendo que um exemplar recebeu uma pintura comemorativa especial, representando um tigre.


O Tigre no Brasil (FAB)
=======================

No Brasil, a hist�ria do F- 5 iniciou na pr�tica em mar�o de 1975, por�m, ele esteve cotado para equipar a FAB desde 1965, em sua vers�o F- 5A/B. Em 1967, ele foi novamente cogitado, desta vez como vetor do projeto SISDACTA. A prefer�ncia era para o F- 4 Phantom, mas este foi vetado pelos americanos, que em contrapartida ofereceram o F- 5C (vers�o proposta pela Northrop com melhorias baseadas no relat�rio de avalia��o feito no Vietn�E.
O impasse norte- americano favoreceu os franceses, tendo a FAB adquirido 16 Dassault Mirage III. Numa nova disputa internacional, realizada a partir de 1971 para substituir os AT- 33A, na qual participaram o Fiat G- 91, MB- 326K, Harrier Mk- 50, Jaguar GR1 e A- 4F, saiu vencedor o ca�a da Northrop, agora em sua vers�o F- 5E. Come�ava a longa hist�ria de sucesso do Tiger II na FAB, que continua at�Ehoje e ainda deve durar at�E2018.
A FAB recebeu 6 F- 5B (FAB 4800 a 4805), 4 F- 5F (FAB 4806 a 4809) e 58 F- 5E (FAB 4820 a 4877) que foram adquiridos em dois lotes distintos. O primeiro lote em 1973, direto da f�brica (06 F- 5B + 36 F- 5E), ao valor de US$ 115 milh�es e o segundo lote, em 1988, ex- USAF (04 F- 5F e 22 F- 5E), ao custo total de US$ 13,1 milh�es. As primeiras aeronaves da "Opera��o Tigre", como ficou conhecido o translado do primeiro lote, foram entregues a partir de 28 de fevereiro de 1975 em Palmdale. Eram 3 F- 5B, que chegaram ao Brasil no dia 06 de mar�o do mesmo ano, sendo seguidos de outros 3 F- 5B em 13 de maio. Em 12 de junho de 1975, chegavam os primeiros 4 F- 5E �EBAGL, dando in��io a uma ponte a�rea que s�Eterminaria em 12 de fevereiro do ano seguinte, totalizando 36 aeronaves.
Em 1985, depois de muito procurar, chegou- se a um acordo com o governo Reagan, que aceitou negociar 4 F- 5F e 22 F- 5E, que sairiam das fileiras da USAF, a um custo de US$ 13,1 milh�es, uma bagatela. Por volta de Setembro de 2006, especulava- se a aquisi��o de 9 aeronaves F- 5E Tiger II, usadas da Ar�bia Saudita, sendo 6 F- 5E e 3 F- 5F. Esta compra, entretanto, n�o foi adiante, vindo a For�a A�rea Brasileira a adquirir um lote de aeronaves pertencentes �EReal For�a A�rea da Jord�nia. No total foram compradas 11 aeronaves, sendo 8 F- 5E monoplaces e 3 F- 5F biplaces. As primeiras aeronaves vindas da Jord�nia chegaram no Brasil em 19 agosto de 2008 e foram enviadas ao Parque de Material da Aeron�utica de S�o Paulo (PAMA- SP). Todas os F- 5 ex- Jord�nia dever�o ser convertidos para o padr�o F- 5EM e F- 5FM.


FONTE : http://pt.wikipedia.org/wiki/Northrop_F- 5E_Tiger_II


CHANGELOG
=========


Vers�o alpha -  0.0.4 04/07/2010
		-  Novas cameras, configura��o de luzes, disponibilidade de uma vers�o sem limites estruturais.
Vers�o alpha -  0.0.3 04/03/2010
		-  Melhorias no FDM, anima��o do trem dianteiro para estrutura de extens�o, trem dianteiro revisado, revis�o do nose_lift.xml e corre��o da troca de pinturas no MP.
Vers�o alpha -  0.0.2 20/12/2009
		-  Melhorias no FDM, corre��es na textura de instrumento e modelo 3d.
Vers�o alpha -  0.0.1 16/12/2009
		-  Primeira apresenta��o do trabalho. Adicionado painel 3d real��tico, capacidade de reabastecimento em v�o (REVO), suporte livery selection, melhorias no FDM e adi��es ao - set.xml.



Desenvolvido pelo Prestes Hangar. Dispon��el em  http://presteshangar.blogspot.com ou http://presteshangar.wikidot.com/start


INSTALA��O
==========

Descompacte o arquivo .zip usando o programa TUGZip na pasta PASTA_BASE_DO_Flightgear\Data\Aircraft


Meus cumprimentos, bons voos,

Prestes Hangar


---------------------------------------------------------------------------------------------------------------------------------


P R E S T E S  H A N G A R  - -  http://presteshangar.blogspot.com  - -   2010


---------------------------------------------------------------------------------------------------------------------------------
